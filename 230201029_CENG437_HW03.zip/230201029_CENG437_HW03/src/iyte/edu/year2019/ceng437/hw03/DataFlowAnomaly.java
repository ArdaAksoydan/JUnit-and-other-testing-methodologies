/**
 *Mehmet Arda Aksoydan - 230201029
 */

package iyte.edu.year2019.ceng437.hw03;

public class DataFlowAnomaly {

	public static void main(String[] args) {
		// All anomalies: dd, ur, du

	}

	/*
	 * Defined and then defined again(dd) considered anomaly because if a same
	 * variable defined two times without any reference between them that means the
	 * first define of variable was redundant.
	 */
	public static int definedAndThenDefinedAgain(int variable) {
		int redundantVariable = variable;

		redundantVariable = 15;

		return redundantVariable;
	}

	/*
	 * Undefined but referenced(ur) is an anomaly where we use a variable in a
	 * computation without initializing it first.
	 */
	public static int undefinedButReferenced(int variable) {
		int unknownVariable;

		int knownVariable = variable - unknownVariable;

		return knownVariable;
	}

	/*
	 * Defined but not referenced(du) considered anomaly because we know that if a
	 * variable does not used in any computation then that variable is useless for
	 * us and we cannot be sure if it's going to be used in near future.
	 */

	public static void definedButNotReferenced(int variable) {

		int uselessVariable = variable;

	}
}