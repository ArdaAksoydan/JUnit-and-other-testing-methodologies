package iyte.edu.year2019.ceng437.hw01;

public enum DeliveryDay {
	
	NEXT_DAY,
	IN_TWO_DAYS,
	IN_A_WEEK
}
