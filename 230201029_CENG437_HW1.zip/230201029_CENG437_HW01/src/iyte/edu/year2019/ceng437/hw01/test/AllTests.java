/**
 *Mehmet Arda Aksoydan - 230201029
 */
package iyte.edu.year2019.ceng437.hw01.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ TestShipment.class, TestDecisionTable.class, TestMenu.class })

public class AllTests {

}