/**
 *Mehmet Arda Aksoydan - 230201029
 */
package iyte.edu.year2019.ceng437.hw01.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import iyte.edu.year2019.ceng437.hw01.DecisionTable;
import iyte.edu.year2019.ceng437.hw01.DeliveryDay;
import iyte.edu.year2019.ceng437.hw01.Shipment;

public class TestDecisionTable {

	protected static Shipment shipment1;
	protected static Shipment shipment2;
	protected static Shipment shipment3;
	protected static Shipment shipment4;

	protected static DecisionTable decisionTable;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {

		shipment1 = new Shipment(150, 2, DeliveryDay.NEXT_DAY);
		shipment2 = new Shipment(75, 6, DeliveryDay.IN_A_WEEK);
		shipment3 = new Shipment(300, 4, DeliveryDay.IN_TWO_DAYS);
		shipment4 = new Shipment(500, 8, DeliveryDay.IN_TWO_DAYS);

		decisionTable = new DecisionTable();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testDecisionTableCalculateShipmentCost() {

		assertEquals(35.0, TestDecisionTable.decisionTable.calculateShipmentCost(shipment1), 0);
		assertEquals(9.0, TestDecisionTable.decisionTable.calculateShipmentCost(shipment2), 0);
		assertEquals(25.0, TestDecisionTable.decisionTable.calculateShipmentCost(shipment3), 0);
		assertEquals(60.0, TestDecisionTable.decisionTable.calculateShipmentCost(shipment4), 0);

		shipment1.setDeliveryDay(DeliveryDay.IN_A_WEEK);
		shipment2.setPurchaseAmount(400);
		shipment3.setPurchaseAmount(100);
		shipment4.setDeliveryDay(DeliveryDay.NEXT_DAY);

		assertEquals(4.0, TestDecisionTable.decisionTable.calculateShipmentCost(shipment1), 0);
		assertEquals(21.0, TestDecisionTable.decisionTable.calculateShipmentCost(shipment2), 0);
		assertEquals(20.0, TestDecisionTable.decisionTable.calculateShipmentCost(shipment3), 0);
		assertEquals(72.0, TestDecisionTable.decisionTable.calculateShipmentCost(shipment4), 0);

		shipment1.setPurchaseAmount(250);
		shipment2.setNumberOfItems(3);
		shipment2.setDeliveryDay(DeliveryDay.NEXT_DAY);
		shipment3.setNumberOfItems(10);
		shipment4.setPurchaseAmount(50);

		assertEquals(20.0, TestDecisionTable.decisionTable.calculateShipmentCost(shipment1), 0);
		assertEquals(40.0, TestDecisionTable.decisionTable.calculateShipmentCost(shipment2), 0);
		assertEquals(35.0, TestDecisionTable.decisionTable.calculateShipmentCost(shipment3), 0);
		assertEquals(40.0, TestDecisionTable.decisionTable.calculateShipmentCost(shipment4), 0);

	}

}
