/*
/Mehmet Arda Aksoydan - 230201029
*/
package iyte.edu.year2019.ceng437.hw01.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import iyte.edu.year2019.ceng437.hw01.DeliveryDay;
import iyte.edu.year2019.ceng437.hw01.Menu;

public class TestMenu {

	protected static Menu menu;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {

		menu = new Menu();

	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testMenuReadPurchaseAmount() {

		assertEquals("Type 275 please", 275, TestMenu.menu.readPurchaseAmount());
		assertEquals("Type -100 please", -100, TestMenu.menu.readPurchaseAmount()); // No exception handling in
																					// readPurchaseAmount()
	}

	@Test
	public void testMenuReadNumberOfItems() {

		assertEquals("Type 5 please", 5, TestMenu.menu.readNumberOfItems());
		assertEquals("Type -3 please", -3, TestMenu.menu.readNumberOfItems());// No exception handling in
																				// readNumberOfItems()

	}

	@Test
	public void testMenuReadDeliveryDay() {

		assertEquals("Type 1 please", DeliveryDay.NEXT_DAY, TestMenu.menu.readDeliveryDay());
		assertEquals("Type 2 please", DeliveryDay.IN_TWO_DAYS, TestMenu.menu.readDeliveryDay());
		assertEquals("Type 3 please", DeliveryDay.IN_A_WEEK, TestMenu.menu.readDeliveryDay());
		assertEquals("Type anything bigger than 3 please", DeliveryDay.IN_A_WEEK, TestMenu.menu.readDeliveryDay());
	}

}