/**
 *Mehmet Arda Aksoydan - 230201029
 */
package iyte.edu.year2019.ceng437.hw01.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import iyte.edu.year2019.ceng437.hw01.DeliveryDay;
import iyte.edu.year2019.ceng437.hw01.Shipment;

public class TestShipment {

	protected static Shipment shipment1;
	protected static Shipment shipment2;
	protected static Shipment shipment3;
	protected static Shipment shipment4;
	protected static Shipment shipment5;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {

		shipment1 = new Shipment(100, 2, DeliveryDay.NEXT_DAY);
		shipment2 = new Shipment(150, 4, DeliveryDay.NEXT_DAY);
		shipment3 = new Shipment(200, 6, DeliveryDay.IN_TWO_DAYS);
		shipment4 = new Shipment(250, 8, DeliveryDay.IN_TWO_DAYS);
		shipment5 = new Shipment(300, 10, DeliveryDay.IN_A_WEEK);
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testShipmentNullObjects() {

		assertNotEquals(null, TestShipment.shipment1);
		assertNotEquals(null, TestShipment.shipment2);
		assertNotEquals(null, TestShipment.shipment3);
		assertNotEquals(null, TestShipment.shipment4);
		assertNotEquals(null, TestShipment.shipment5);

	}

	@Test
	public void testShipmentGetPurchaseAmount() {

		assertEquals(100, TestShipment.shipment1.getPurchaseAmount());
		assertEquals(150, TestShipment.shipment2.getPurchaseAmount());
		assertEquals(200, TestShipment.shipment3.getPurchaseAmount());
		assertEquals(250, TestShipment.shipment4.getPurchaseAmount());
		assertEquals(300, TestShipment.shipment5.getPurchaseAmount());

		TestShipment.shipment1.setPurchaseAmount(200);
		TestShipment.shipment2.setPurchaseAmount(-150);
		TestShipment.shipment3.setPurchaseAmount(0);
		TestShipment.shipment4.setPurchaseAmount(2000000);
		TestShipment.shipment5.setPurchaseAmount(-0);

		assertEquals(200, TestShipment.shipment1.getPurchaseAmount());
		assertEquals(-150, TestShipment.shipment2.getPurchaseAmount());
		assertEquals(0, TestShipment.shipment3.getPurchaseAmount());
		assertEquals(2000000, TestShipment.shipment4.getPurchaseAmount());
		assertEquals(0, TestShipment.shipment5.getPurchaseAmount());

	}

	@Test
	public void testShipmentGetNumberOfItems() {

		assertEquals(2, TestShipment.shipment1.getNumberOfItems());
		assertEquals(4, TestShipment.shipment2.getNumberOfItems());
		assertEquals(6, TestShipment.shipment3.getNumberOfItems());
		assertEquals(8, TestShipment.shipment4.getNumberOfItems());
		assertEquals(10, TestShipment.shipment5.getNumberOfItems());

		TestShipment.shipment1.setNumberOfItems(47);
		TestShipment.shipment2.setNumberOfItems(72);
		TestShipment.shipment3.setNumberOfItems(0);
		TestShipment.shipment4.setNumberOfItems(-10);
		TestShipment.shipment5.setNumberOfItems(-32);

		assertEquals(47, TestShipment.shipment1.getNumberOfItems());
		assertEquals(72, TestShipment.shipment2.getNumberOfItems());
		assertEquals(0, TestShipment.shipment3.getNumberOfItems());
		assertEquals(-10, TestShipment.shipment4.getNumberOfItems());
		assertEquals(-32, TestShipment.shipment5.getNumberOfItems());

	}

	@Test
	public void testShipmentGetDeliveryDay() {

		assertEquals(DeliveryDay.NEXT_DAY, TestShipment.shipment1.getDeliveryDay());
		assertEquals(DeliveryDay.NEXT_DAY, TestShipment.shipment2.getDeliveryDay());
		assertEquals(DeliveryDay.IN_TWO_DAYS, TestShipment.shipment3.getDeliveryDay());
		assertEquals(DeliveryDay.IN_TWO_DAYS, TestShipment.shipment4.getDeliveryDay());
		assertEquals(DeliveryDay.IN_A_WEEK, TestShipment.shipment5.getDeliveryDay());

		TestShipment.shipment1.setDeliveryDay(null);
		TestShipment.shipment2.setDeliveryDay(DeliveryDay.IN_TWO_DAYS);
		TestShipment.shipment3.setDeliveryDay(DeliveryDay.IN_TWO_DAYS);
		TestShipment.shipment4.setDeliveryDay(DeliveryDay.IN_A_WEEK);
		TestShipment.shipment5.setDeliveryDay(DeliveryDay.NEXT_DAY);

		assertEquals(null, TestShipment.shipment1.getDeliveryDay());
		assertEquals(DeliveryDay.IN_TWO_DAYS, TestShipment.shipment2.getDeliveryDay());
		assertEquals(DeliveryDay.IN_TWO_DAYS, TestShipment.shipment3.getDeliveryDay());
		assertEquals(DeliveryDay.IN_A_WEEK, TestShipment.shipment4.getDeliveryDay());
		assertEquals(DeliveryDay.NEXT_DAY, TestShipment.shipment5.getDeliveryDay());

	}

	@Test
	public void testShipmentToString() {

		assertEquals("Shipment [purchaseAmount=" + TestShipment.shipment1.getPurchaseAmount() + ", numberOfItems="
				+ TestShipment.shipment1.getNumberOfItems() + ", deliveryDay=" + TestShipment.shipment1.getDeliveryDay()
				+ "]", TestShipment.shipment1.toString());
		assertEquals("Shipment [purchaseAmount=" + TestShipment.shipment2.getPurchaseAmount() + ", numberOfItems="
				+ TestShipment.shipment2.getNumberOfItems() + ", deliveryDay=" + TestShipment.shipment2.getDeliveryDay()
				+ "]", TestShipment.shipment2.toString());
		assertEquals("Shipment [purchaseAmount=" + TestShipment.shipment3.getPurchaseAmount() + ", numberOfItems="
				+ TestShipment.shipment3.getNumberOfItems() + ", deliveryDay=" + TestShipment.shipment3.getDeliveryDay()
				+ "]", TestShipment.shipment3.toString());
		assertEquals("Shipment [purchaseAmount=" + TestShipment.shipment4.getPurchaseAmount() + ", numberOfItems="
				+ TestShipment.shipment4.getNumberOfItems() + ", deliveryDay=" + TestShipment.shipment4.getDeliveryDay()
				+ "]", TestShipment.shipment4.toString());
		assertEquals("Shipment [purchaseAmount=" + TestShipment.shipment5.getPurchaseAmount() + ", numberOfItems="
				+ TestShipment.shipment5.getNumberOfItems() + ", deliveryDay=" + TestShipment.shipment5.getDeliveryDay()
				+ "]", TestShipment.shipment5.toString());

	}

}