package iyte.edu.year2019.ceng437.hw02;

public class Main {

	public static void main(String[] args) {

		SimpleClass simpleClass = new SimpleClass();

		int Array[] = { 2, 7, 9, 34, 11, 15, 1 };

		int size = Array.length;

		Array = simpleClass.insertionSort(Array, size);

		for (int i = 0; i < size; i++) {
			System.out.print(Array[i] + " ");
		}

	}

}