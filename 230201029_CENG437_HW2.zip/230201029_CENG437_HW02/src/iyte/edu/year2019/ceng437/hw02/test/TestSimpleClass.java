package iyte.edu.year2019.ceng437.hw02.test;

import org.junit.Assert;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import iyte.edu.year2019.ceng437.hw02.SimpleClass;

class TestSimpleClass {

	protected static SimpleClass simpleClass;

	protected static int firstArr[] = { 10, 9 };
	protected static int secondArr[] = { 13 };
	protected static int thirdArr[] = { 1, 3 };

	@BeforeAll
	static void setUpBeforeClass() throws Exception {

		simpleClass = new SimpleClass();

	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testFirstPath() {

		int Arr[] = { 9, 10 };

		Assert.assertArrayEquals(Arr, simpleClass.insertionSort(firstArr, 2));
	}

	@Test
	void testSecondPath() {

		int Arr[] = { 13 };

		Assert.assertArrayEquals(Arr, simpleClass.insertionSort(secondArr, 1));
	}

	@Test
	void testThirdPath() {

		int Arr[] = { 1, 3 };

		Assert.assertArrayEquals(Arr, simpleClass.insertionSort(thirdArr, 2));
	}
}
